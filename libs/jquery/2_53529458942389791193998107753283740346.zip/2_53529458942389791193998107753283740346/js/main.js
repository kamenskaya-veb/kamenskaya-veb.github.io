$(function() {
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:30,
        nav:true,
        margin: 90,
        dots: false,

        navText: ['', ''],
        responsive:{
            0:{
                items:1,
                slideBy: 1
            },
            500:{
                items:2,
                slideBy: 2
            },
            760:{
                items:3,
                slideBy: 3
            },
            1000:{
                items:4,
                slideBy: 4
            },
            1200:{
                items:6,
                slideBy: 6
            },
            1500:{
              items:8,
              slideBy: 8
            }
        }

    });

    
    // $('.h-1').hover(
    //     function(){
    //         $('.img__first').css('background','url(../img/item-1-1.png)no-repeat center center/ cover');
    //     },
        
    // );



     $('.title-1').on('mouseover', function(){
        $('.img__first').css('background', 'url(../img/item-1-1.png)no-repeat center center/ cover');
      })
    $('.title-1').on('mouseout', function(){
        $('.img__first').css('background', 'url(../img/item-1.png)no-repeat center center/ cover');
      })

      $('.title-2').on('mouseover', function(){
        $('.img__first2').css('background', 'url(../img/item-1-2.png)no-repeat center center');
      })
    $('.title-2').on('mouseout', function(){
        $('.img__first2').css('background', 'url(../img/item-2.png)no-repeat center center');
      })

      $('.title-3').on('mouseover', function(){
        $('.img__first3').css('background', 'url(../img/item-1-3.png)no-repeat center center/ cover');
      })
    $('.title-3').on('mouseout', function(){
        $('.img__first3').css('background', 'url(../img/item-3.png)no-repeat center center/ cover');
      })

      $('.title-4').on('mouseover', function(){
        $('.img__first4').css('background', 'url(../img/item-1-4.png)no-repeat center center/ cover');
      })
    $('.title-4').on('mouseout', function(){
        $('.img__first4').css('background', 'url(../img/item-4.png)no-repeat center center/ cover');
      })

      $('.title-5').on('mouseover', function(){
        $('.img__first5').css('background', 'url(../img/item-1-5.png)no-repeat center center/ cover');
      })
    $('.title-5').on('mouseout', function(){
        $('.img__first5').css('background', 'url(../img/item-5.png)no-repeat center center/ cover');
      })

      $('.title-6').on('mouseover', function(){
        $('.img__first6').css('background', 'url(../img/item-1-6.png)no-repeat center center/ cover');
      })
    $('.title-6').on('mouseout', function(){
        $('.img__first6').css('background', 'url(../img/item-6.png)no-repeat center center/ cover');
      })

      $('.title-7').on('mouseover', function(){
        $('.img__first7').css('background', 'url(../img/item-1-7.png)no-repeat center center/ cover');
      })
    $('.title-7').on('mouseout', function(){
        $('.img__first7').css('background', 'url(../img/item-7.png)no-repeat center center/ cover');
      })

      $('.title-8').on('mouseover', function(){
        $('.img__first8').css('background', 'url(../img/item-1-8.png)no-repeat center center/ cover');
      })
    $('.title-8').on('mouseout', function(){
        $('.img__first8').css('background', 'url(../img/item-8.png)no-repeat center center/ cover');
      })

      $('.title-9').on('mouseover', function(){
        $('.img__first9').css('background', 'url(../img/item-1-9.png)no-repeat center center/ cover');
      })
    $('.title-9').on('mouseout', function(){
        $('.img__first9').css('background', 'url(../img/item-9.png)no-repeat center center/ cover');
      })

      $('.title-10').on('mouseover', function(){
        $('.img__first10').css('background', 'url(../img/item-1-10.png)no-repeat center center/ cover');
      })
    $('.title-10').on('mouseout', function(){
        $('.img__first10').css('background', 'url(../img/item-10.png)no-repeat center center/ cover');
      })

      $('.title-11').on('mouseover', function(){
        $('.img__first11').css('background', 'url(../img/item-1-11.png)no-repeat center center/ cover');
      })
    $('.title-11').on('mouseout', function(){
        $('.img__first11').css('background', 'url(../img/item-11.png)no-repeat center center/ cover');
      })
        
});

// document.getElementsByClassName("h1")[0].relatedTarget = function() {
// document.getElementsByClassName("img__first")[0].style.display = 'url(../img/item-1-1.png)no-repeat center center/ cover';
//     }

    /* этот код помечает картинки, для удобства разработки */
   